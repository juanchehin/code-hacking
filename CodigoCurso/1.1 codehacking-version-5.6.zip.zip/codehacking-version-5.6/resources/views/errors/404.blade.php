@extends('layouts.app')

@section('content')
    <h1 class="text-center">OOPS, it looks like you are in the wrong place</h1>
@stop